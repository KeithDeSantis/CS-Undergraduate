//
// Created by 14132 on 2/1/2020.
//
#ifndef INC_2020HW2STARTER_BRAIN_H
#include <stdio.h>
#include <stdlib.h>
#include "tests.h"
#include "space.h"
#include "marker.h"
#include "LinkedList.h"

#define INC_2020HW2STARTER_BRAIN_H

void mastermind(int*, int);

#endif
