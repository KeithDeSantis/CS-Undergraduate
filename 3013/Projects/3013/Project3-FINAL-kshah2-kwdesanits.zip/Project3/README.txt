We enjoyed this project a lot! 

Init: 
 
We ran into some trouble with void* and casting arithmetic but after some experimentation and supplementary reading we figured it out.  This arithemetic is best seen in the init function, where we were having trouble with the math.c ceil() function (for rounding up to page_size) and instead used size/getpagesize() and size % getpagesize() to create our own (less nice looking) version.  After calling mmap we initialize our first node in the list and then return.  

Destroy:

Destroy is simple enough as we just call munmap and check for errors.  

Walloc:

Walloc was straightforward enough, you must iterate through the list looking for large enough free spaces, then it just comes down to linked list management with fwd and bwd pointers.  If you get through the whole list and no chunk is big enough (as seen in our do while loop) you set an error and return.  

wfree:

Finally, in wfree we use a do while loop and two abstractions called "start" and "end" that, starting from the node passed into the function, search the list forward and backward until they both hit something other than a free node (allocated node or NULL), then using those two we manage the linked list and node_t fields, turning everything between start and end (inclusively) to one big free node, coalescing and handling all cases.
