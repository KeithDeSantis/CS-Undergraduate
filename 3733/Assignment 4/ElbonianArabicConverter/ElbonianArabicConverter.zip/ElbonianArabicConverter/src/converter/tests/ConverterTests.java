package converter.tests;

import converter.ElbonianArabicConverter;
import converter.exceptions.MalformedNumberException;
import converter.exceptions.ValueOutOfBoundsException;
import org.junit.Test;

import static org.junit.Assert.assertEquals;

/**
 * Test cases for the ElbonianArabicConverter class.
 */
public class ConverterTests {

    @Test
    public void ElbonianToArabicSampleTest() throws MalformedNumberException, ValueOutOfBoundsException {
        ElbonianArabicConverter converter = new ElbonianArabicConverter("1");
        assertEquals(converter.toElbonian(), "I");
    }

    @Test
    public void testing40ToElbonian() throws MalformedNumberException, ValueOutOfBoundsException {
        ElbonianArabicConverter converter = new ElbonianArabicConverter("40");
        assertEquals(converter.toElbonian(), "N");
    }

    @Test
    public void testing43ToElbonian() throws MalformedNumberException, ValueOutOfBoundsException {
        ElbonianArabicConverter converter = new ElbonianArabicConverter("43");
        assertEquals(converter.toElbonian(), "NIII");
    }

    @Test(expected = MalformedNumberException.class)
    public void testingExceptionForToElbonian() throws MalformedNumberException, ValueOutOfBoundsException {
        ElbonianArabicConverter converter = new ElbonianArabicConverter("MMMM");
        converter.toArabic();
    }

    @Test(expected = MalformedNumberException.class)
    public void testingExceptionForToElbonian1() throws MalformedNumberException, ValueOutOfBoundsException {
        ElbonianArabicConverter converter = new ElbonianArabicConverter("FCNXYIDNN");
        converter.toArabic();
    }

    @Test(expected = ValueOutOfBoundsException.class)
    public void testingExceptionForOutOfBounds() throws MalformedNumberException, ValueOutOfBoundsException {
        ElbonianArabicConverter converter = new ElbonianArabicConverter("15000");
        converter.toElbonian();
    }

    @Test
    public void ArabicToElbonian41() throws MalformedNumberException, ValueOutOfBoundsException {
        ElbonianArabicConverter converter = new ElbonianArabicConverter("41");
        assertEquals(converter.toElbonian(), "NI");
    }

    @Test
    public void ElbonianToArabicDX() throws MalformedNumberException, ValueOutOfBoundsException {
        ElbonianArabicConverter converter = new ElbonianArabicConverter("DX");
        assertEquals(converter.toArabic(),510);
    }

   @Test
   public void ElbonianToArabicVI() throws MalformedNumberException, ValueOutOfBoundsException {
        ElbonianArabicConverter converter =  new ElbonianArabicConverter("VI");
        assertEquals(converter.toArabic(), 6);
   }

    @Test
    public void ElbonianToArabicMDLI() throws MalformedNumberException, ValueOutOfBoundsException {
        ElbonianArabicConverter converter =  new ElbonianArabicConverter("MDLI");
        assertEquals(converter.toArabic(), 1551);
    }

    @Test
    public void ArabicToElbonian9() throws MalformedNumberException, ValueOutOfBoundsException {
        ElbonianArabicConverter converter = new ElbonianArabicConverter("9");
        assertEquals(converter.toElbonian(), "VY");
    }

    @Test
    public void ArabicToElbonian500() throws MalformedNumberException, ValueOutOfBoundsException {
        ElbonianArabicConverter converter = new ElbonianArabicConverter("500");
        assertEquals(converter.toElbonian(), "D");
    }

    @Test(expected = MalformedNumberException.class)
    public void malformedNumberTest() throws MalformedNumberException, ValueOutOfBoundsException {
        throw new MalformedNumberException("TEST");
    }



    @Test(expected = ValueOutOfBoundsException.class)
    public void valueOutOfBoundsTest() throws MalformedNumberException, ValueOutOfBoundsException {
        throw new ValueOutOfBoundsException("0");
    }

    // TODO Add more test cases
}
